export const environment = {
  production: true,
  apiKey: "AIzaSyA1mseL1JCxunT-CmzkeYHCQ9jqb9Wcouc",
};
