import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AccountService } from '../services/Account.service';
import { Account } from './../shared/createAccount.model';

@Component({
  selector: 'app-view-account',
  templateUrl: './view-account.component.html',
  styleUrls: ['./view-account.component.css']
})
export class ViewAccountComponent implements OnInit {
   account:Account;
    id: string;
  constructor(private accountService:AccountService,
    private route:ActivatedRoute) { 
  }

  ngOnInit(): void {
    const id = this.route.snapshot.params['id'];
    this.accountService.entities$.subscribe((accounts) => {
      this.account = accounts.find((account) => account.id === id);
    });
  }
 }
 

