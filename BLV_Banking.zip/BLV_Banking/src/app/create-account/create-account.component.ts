import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { AccountService } from '../services/Account.service';
import { Account } from './../shared/createAccount.model';

@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.css']
})
export class CreateAccountComponent implements OnInit {
  createForm:FormGroup;
  accountNumber: number;
  constructor(private accountService:AccountService,
    private router:Router) { }

  ngOnInit(): void {    
    this.createForm=new FormGroup({
      accounttype:new FormControl(null,[
        Validators.required,
      ]),
      firstname:new FormControl(null,[
        Validators.required,
        Validators.minLength(3),
      ]),
      lastname:new FormControl(null,[
        Validators.required,
        Validators.minLength(3),
      ]),
      email:new FormControl(null,[
        Validators.required,
        Validators.email,
      ]),
      gender:new FormControl(null,[
        Validators.required,
      ]),
       username:new FormControl(null,[
        Validators.required,
        Validators.minLength(3),
      ]),
      balance:new FormControl(null,[
        Validators.required,
      ]),
      address:new FormControl(null,[
        Validators.required,
      ]),
      income:new FormControl(null,[
        Validators.required,
      ]),
      mobile:new FormControl(null,[
        Validators.required,
      ]),
      password:new FormControl(null,[Validators.required,Validators.minLength(4)]),
      
      date:new FormControl(null,[Validators.required])
    });
  }
  showDesignationErrors()
  {
    const passwordForm=this.createForm.get('password');
    if(passwordForm.touched && !passwordForm.valid)
    {
      if(passwordForm.errors.required)
      {
        return 'Password is required';
      }
      if(passwordForm.errors.minLength)
      {
        return 'Password should be of minimum 4 characters length';
      }
    }
  }
  onCreate()
{
  if(!this.createForm.valid){
   return;
   }
  const account:Account=this.createForm.value;
   account.accountNumber=this.accountNumberGeneration();
   console.log(account.accountNumber);
  this.accountService.add(account).subscribe((data)=>
  {
    this.router.navigate(['/accounts']);
  });
   this.createForm.reset();
  }
  accountNumberGeneration(){
    let min=11111111111111;
    let max=99999999999999;
    return this.accountNumber=Math.floor(Math.random()*(max-min+1))+min;
    }
 }


