import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { Account } from './../shared/createAccount.model';
import { AccountService } from '../services/Account.service';

@Component({
  selector: 'app-manage-account',
  templateUrl: './manage-account.component.html',
  styleUrls: ['./manage-account.component.css']
})
export class ManageAccountComponent implements OnInit {
  accounts:any;
  constructor(private accountService:AccountService) { }

  ngOnInit(): void {
   this.accounts= this.accountService.getAll();
  }

}
