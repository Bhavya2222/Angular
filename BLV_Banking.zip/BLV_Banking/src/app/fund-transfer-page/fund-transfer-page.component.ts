import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Account,fund } from './../shared/createAccount.model';
import { AccountService } from '../services/Account.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import {FundTransferService} from './../services/FundTransferService';
import {AuthService} from './../auth/auth.service';

@Component({
  selector: 'app-fund-transfer-page',
  templateUrl: './fund-transfer-page.component.html',
  styleUrls: ['./fund-transfer-page.component.css']
})
export class FundTransferPageComponent implements OnInit {
  fundTransferForm:FormGroup;
  accounts:any;
  account: any;
  srcaccount:any;
  destaccount:any;
  res: string;
  constructor(private accountService:AccountService,
    private FundTransferService:FundTransferService,
    private authService:AuthService,
    private router:Router) { }

  ngOnInit(): void {
    this.fundTransferForm=new FormGroup({
      amount:new FormControl(null,[
        Validators.required,
      ]),   
      accountNumber:new FormControl(null,[
        Validators.required,
      ]),             
    });  
    this.accounts= this.accountService.getAll();
  }
  
  Transfer(form:fund){
    console.log(this.accounts);
    if(!this.fundTransferForm.valid){
      return;
    }
    debugger;
    const email=this.authService.email ;
    console.log(email);
    this.accountService.entities$.subscribe((accounts)=>
    {
     let accountList:any=[];
     Object.assign(accountList,accounts);     
      console.log(accounts);
      this.account=accounts.filter(account=>account.email == email);
      console.log(email);
      console.log(this.account);
       //srcaccount:this.account;
      let srcaccount:Account={accounttype:"",firstname:"",lastname:"",email:"",gender:"",date:"",
      username:"",password:"",balance:0,address:"",deposit:0,mobile:0,income:0,accountNumber:0,amount:0};
       Object.assign(srcaccount,this.account[0]);
       //let srcaccount=Object.assign([],this.account);
      //let srcaccount=this.account[0];
      var srcacnt = Number(srcaccount.balance);
      console.log(srcacnt);
      srcacnt= srcacnt - (Number(this.fundTransferForm.get('amount').value));
      console.log(srcacnt);
      console.log(Number(this.fundTransferForm.get('amount').value));
      let destaccount:any={};     
      let acc=accountList.filter(x=>x.accountNumber == Number(this.fundTransferForm.get('accountNumber').value));
      Object.assign(destaccount,acc[0]);
      var destacnt = Number(destaccount.balance);
      destacnt=destacnt + (Number(this.fundTransferForm.get('amount').value));
      console.log(destacnt);
      form.srcaccount= srcaccount.accountNumber;
      form.srcaccnme=srcaccount.firstname;
      form.destaccnme=destaccount.firstname;
      srcaccount.balance=srcacnt;
      destaccount.balance=destacnt;
      var srcan=Number(srcaccount.accountNumber);
      srcaccount.accountNumber=srcan;   
      console.log(form,form.srcaccount,form.srcaccnme,form.destaccnme);
      this.res =this.FundTransferService.fundTransfer(srcaccount,destaccount,form);
      console.log(srcaccount.id);
      console.log(destaccount.id);
      if(this.res == "success"){
      alert("Amount Transferred Successfully");
      this.authService.isValidUser=true;
      this.router.navigate(['/transaction-page']);
  }
  this.fundTransferForm.reset();
   }); 
   // });
  }

}
