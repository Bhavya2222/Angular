import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth/auth.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm:FormGroup;
  error: string = null;
  isLoading = false;
  constructor(private authService: AuthService,private router:Router) { }

  ngOnInit(): void {
    this.loginForm=new FormGroup({
      email:new FormControl(null,[
        Validators.required,
        Validators.email,
      ]),
      password:new FormControl(null,[Validators.required,Validators.minLength(9)]),
    });
  }
  showDesignationErrors()
  {
    const passwordForm=this.loginForm.get('password');
    if(passwordForm.touched && !passwordForm.valid)
    {
      if(passwordForm.errors.required)
      {
        return 'Password is required';
      }
      if(passwordForm.errors.minLength)
      {
        return 'Password should be of minimum 9 characters length';
      }
    }
  }
  onLogin()
{
    const email = this.loginForm.value.email;
    const password = this.loginForm.value.password;
    this.isLoading = true;
    if(!this.loginForm.valid){
      return;
    }
    this.authService.login(email, password).subscribe(
      resData => {
        this.authService.email=email;
        console.log(resData);
        localStorage.setItem("bankToken",resData.idToken);
        this.isLoading = false;
        this.authService.isUserLogged=true;
        this.router.navigate(['/account-summary']);
      },
      errorMessage => {
        console.log(errorMessage);
        this.error = errorMessage;
        this.isLoading = false;
      }
    );
    this.loginForm.reset();
   }
}
