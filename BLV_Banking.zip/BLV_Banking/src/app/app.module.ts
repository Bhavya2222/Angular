import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { Store, StoreModule } from '@ngrx/store';
import { CreateAccountComponent } from './create-account/create-account.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { ManageAccountComponent } from './manage-account/manage-account.component';
import { UpdateAccountComponent } from './update-account/update-account.component';
import { ViewAccountComponent } from './view-account/view-account.component';
import { TransactionPageComponent } from './transaction-page/transaction-page.component';
import { FundTransferPageComponent } from './fund-transfer-page/fund-transfer-page.component';
import { AccountSummaryComponent } from './account-summary/account-summary.component';
import { MiniStatementComponent } from './mini-statement/mini-statement.component';
import {HeaderComponent} from './header/header.component';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { environment } from 'src/environments/environment';
import { EffectsModule } from '@ngrx/effects';
import { EntityDataModule, EntityDataService } from '@ngrx/data';
import { entityConfig } from './shared/entity-metadata';
import { HttpClientModule } from '@angular/common/http';
import {AccountDataService} from '../app/services/Account-data.service';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { HomeComponent } from './home/home.component';
import { AccountsResolver } from './services/Account.resolver';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    CreateAccountComponent,
    ManageAccountComponent,
    UpdateAccountComponent,
    ViewAccountComponent,
    TransactionPageComponent,
    FundTransferPageComponent,
    AccountSummaryComponent,
    MiniStatementComponent,
    HeaderComponent,
    AdminLoginComponent,
    HomeComponent    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    StoreModule.forRoot({}),
    StoreDevtoolsModule.instrument({
      logOnly:environment.production,
    }),
    EffectsModule.forRoot([]),
    EntityDataModule.forRoot(entityConfig)

  ],
  providers: [AccountDataService,AccountsResolver],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(
    entityDataService:EntityDataService,
    AccountDataService:AccountDataService
    ){
      entityDataService.registerService('Account',AccountDataService);
    }
 }
