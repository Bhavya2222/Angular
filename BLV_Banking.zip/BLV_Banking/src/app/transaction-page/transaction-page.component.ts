import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth/auth.service';
import {FundTransferService} from './../services/FundTransferService';
import { AccountService } from '../services/Account.service';
import { Account,fund } from './../shared/createAccount.model';

@Component({
  selector: 'app-transaction-page',
  templateUrl: './transaction-page.component.html',
  styleUrls: ['./transaction-page.component.css']
})
export class TransactionPageComponent implements OnInit {
  accounts:any;
  account: any;
  srcaccount:any;
  destaccount:any;
  form:any;

  constructor(private FundTransferService:FundTransferService,
    private authService:AuthService,
    private accountService:AccountService) { }

  ngOnInit(): void {
   
    const email=this.authService.email ;
    console.log(email);
    this.accountService.entities$.subscribe((accounts)=>
    {
      this.account=accounts.filter(account=>account.email == email);
      console.log(email);
      console.log(this.account);
    })
     this.account=this.FundTransferService.fundTransfer(this.srcaccount.id,this.destaccount.id,this.form);
      return this.srcaccount,this.destaccount,this.form;
      console.log(this.account);
  }

}
