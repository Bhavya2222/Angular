import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth/auth.service';


@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {
  isLoading = false;
  adminloginForm:FormGroup;
   error: string = null;
  constructor(private authService: AuthService,private router:Router) { }

  ngOnInit(): void {
    this.adminloginForm=new FormGroup({
      email:new FormControl(null,[
        Validators.required,
        Validators.email,
      ]), 
      password:new FormControl(null,[Validators.required,Validators.minLength(4)]),     
    });
  }
  showDesignationErrors()
  {
    const passwordForm=this.adminloginForm.get('password');
    if(passwordForm.touched && !passwordForm.valid)
    {
      if(passwordForm.errors.required)
      {
        return 'Password is required';
      }
      if(passwordForm.errors.minLength)
      {
        return 'Password should be of minimum 4 characters length';
      }
    }
  }
  onAdminLogin()
  {
    const email = this.adminloginForm.value.email;
    const password = this.adminloginForm.value.password;
    this.isLoading = true;
    if(!this.adminloginForm.valid){
      return;
    }
    this.authService.login(email, password).subscribe(
      resData => {
        console.log(resData);
        localStorage.setItem("bankToken",resData.idToken);
        this.isLoading = false;
        this.authService.isAdminLogged=true;
        this.router.navigate(['/manage-account']);
      },
      errorMessage => {
        console.log(errorMessage);
        this.error = errorMessage;
        this.isLoading = false;
      }
    );
    this.adminloginForm.reset();
   }
  
}

