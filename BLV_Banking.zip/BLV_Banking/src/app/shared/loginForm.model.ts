export interface loginFormData{
    email:string;
    password:string;
}