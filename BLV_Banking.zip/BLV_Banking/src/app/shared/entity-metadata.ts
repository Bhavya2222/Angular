import { EntityDataModuleConfig, EntityMetadataMap } from '@ngrx/data';

const entityMetadata: EntityMetadataMap = {
    Account: {},
};

export const entityConfig: EntityDataModuleConfig = {
    entityMetadata,
};