export interface Account{
    id?:string;
    accounttype:string;
    firstname:string;
    lastname:string;
    email:string;
    gender:string;
    date:string;
    username:string;
    password:string;
    balance:number;
    address:string;
    deposit:number;    
    mobile:number;
    income:number;
    accountNumber:number;
    amount:number;
}

export interface fund{
    srcaccnme:string;
    destaccnme:string;
    accountNumber:any;
    amount:any;
    srcaccount:any;
    destaccount:any;
    id:any;
}