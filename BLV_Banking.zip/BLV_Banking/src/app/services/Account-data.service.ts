import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {DefaultDataService, HttpUrlGenerator} from '@ngrx/data';
import { Observable} from 'rxjs';
import {Account} from './../shared/createAccount.model';
import { map } from 'rxjs/operators';
import { Update } from '@ngrx/entity';
import { environment } from 'src/environments/environment';
import { AuthResponseData } from '../auth/auth.service';


@Injectable()
export class AccountDataService extends DefaultDataService<Account>{
    constructor(http:HttpClient,httpUrlGenerator:HttpUrlGenerator)
    {
        super('Account',http,httpUrlGenerator);
    }
    getAll(){  
      return this.http.get('https://account-74c06-default-rtdb.firebaseio.com/accounts.json?auth=' + localStorage.getItem("bankToken"))
     .pipe(
         map((data)=>{
         let accounts:Account[]=[];
         for(let key in data){
            accounts.push({...data[key],id:key});
         }
         return accounts;
     })
     );
  }

  add(account:Account):Observable<Account>{
   this.http.post<AuthResponseData>(
    "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key="+environment.apiKey,{
    email:account.email,
    password:account.password,
    returnSecureToken:true
   }).subscribe(resdata=>{
         this.http.post<{name:string}>(
            'https://account-74c06-default-rtdb.firebaseio.com/accounts.json?auth='+ localStorage.getItem("bankToken"),account)
            .subscribe(account=>{
                return account;
   })
 });
 return ;
}

update(account:Update<Account>):Observable<Account>{
    return this.http.put<Account>(
        `https://account-74c06-default-rtdb.firebaseio.com/accounts/${account.id}.json?auth=`+ localStorage.getItem("bankToken"),
        { ...account.changes}
        );
  }
 

 }