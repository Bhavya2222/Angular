import { Injectable } from "@angular/core";
import {Account, fund} from './../shared/createAccount.model';
import { HttpClient,HttpClientModule } from '@angular/common/http';
import { Observable } from "rxjs";

@Injectable({
    providedIn:'root',
})

export class FundTransferService {
    constructor(private http:HttpClient){}
    fundTransfer(srcaccount:Account,destaccount:Account,fundForm:fund){
      console.log(srcaccount,destaccount,fundForm);
         this.http.put<{name:string}>("https://account-74c06-default-rtdb.firebaseio.com/accounts/ "+srcaccount.id +".json?auth=" + localStorage.getItem("bankToken"),srcaccount).subscribe(srcdata =>{
        this.http.put<{name:string}>("https://account-74c06-default-rtdb.firebaseio.com/accounts/ "+destaccount.id +".json?auth=" + localStorage.getItem("bankToken"),destaccount).subscribe(destdata =>{
    })
  });
  return "success";
    }
}