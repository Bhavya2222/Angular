import { mergeMap, map, first, tap } from 'rxjs/operators';
import { AccountService } from './Account.service';
import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  Resolve,
  RouterStateSnapshot,
} from '@angular/router';
import { Observable, of } from 'rxjs';

@Injectable()
export class AccountsResolver implements Resolve<boolean> {
  constructor(private AccountService: AccountService) {}
  resolve(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean | Observable<boolean> | Promise<boolean> {
    return this.AccountService.loaded$.pipe(
      tap((loaded) => {
        if (!loaded) {
          this.AccountService.getAll();
        }
      }),
      first()
    );
  }
}