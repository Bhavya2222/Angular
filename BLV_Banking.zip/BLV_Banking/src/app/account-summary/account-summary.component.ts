import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { AuthService } from '../auth/auth.service';
import { AccountService } from '../services/Account.service';
import { Account } from './../shared/createAccount.model';

@Component({
  selector: 'app-account-summary',
  templateUrl: './account-summary.component.html',
  styleUrls: ['./account-summary.component.css']
})
export class AccountSummaryComponent implements OnInit {
  account: Account[];
 
  constructor(private accountService:AccountService,
    private authService: AuthService) { }

  ngOnInit(): void {
  const email=this.authService.email ;
  console.log(email);
  this.accountService.entities$.subscribe((accounts)=>
  {
    this.account=accounts.filter(account=>account.email == email);
    console.log(this.account);
 });
}
}
