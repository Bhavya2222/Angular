import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccountSummaryComponent } from './account-summary/account-summary.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { CreateAccountComponent } from './create-account/create-account.component';
import { FundTransferPageComponent } from './fund-transfer-page/fund-transfer-page.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { ManageAccountComponent } from './manage-account/manage-account.component';
import { MiniStatementComponent } from './mini-statement/mini-statement.component';
import { AccountsResolver } from './services/Account.resolver';
import { TransactionPageComponent } from './transaction-page/transaction-page.component';
import { UpdateAccountComponent } from './update-account/update-account.component';
import { ViewAccountComponent } from './view-account/view-account.component';


const routes: Routes = [
  {
    path:'login',component:LoginComponent
  },
  {
    path:'admin-login',component:AdminLoginComponent
  },
  {
    path:'',component:HomeComponent
  },
  {
    path:'header',component:HeaderComponent
  },
  {
    path:'create-account',component:CreateAccountComponent,resolve:{services:AccountsResolver}
  },
  {
    path:'manage-account',component:ManageAccountComponent,resolve:{services:AccountsResolver}
  },
  {
    path:'update-account/:id', component:UpdateAccountComponent,resolve:{services:AccountsResolver}
   },
   {
    path:'view-account/:id', component:ViewAccountComponent,resolve:{services:AccountsResolver}
  },        
  {
    path:'transaction-page',component:TransactionPageComponent
  },
  {
    path:'fund-transfer-page',component:FundTransferPageComponent,resolve:{services:AccountsResolver}
  },
  {
    path:'account-summary',component:AccountSummaryComponent,resolve:{services:AccountsResolver}
  },
  {
    path:'mini-statement',component:MiniStatementComponent
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

