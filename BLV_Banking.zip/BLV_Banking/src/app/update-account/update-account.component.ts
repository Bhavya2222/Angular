import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountService } from '../services/Account.service';

@Component({
  selector: 'app-update-account',
  templateUrl: './update-account.component.html',
  styleUrls: ['./update-account.component.css']
})
export class UpdateAccountComponent implements OnInit {
  editForm:FormGroup;
  id:string;
  constructor(private AccountService:AccountService,
    private route:ActivatedRoute,
    private router:Router) { }

  ngOnInit(): void {
    this.editForm= new FormGroup({
      accounttype:new FormControl(null,[
        Validators.required,
      ]),
      firstname:new FormControl(null,[
        Validators.required,
        Validators.minLength(3),
      ]),
      lastname:new FormControl(null,[
        Validators.required,
        Validators.minLength(3),
      ]),
      email:new FormControl(null,[
        Validators.required,
        Validators.email,
      ]),
      gender:new FormControl(null,[
        Validators.required,
      ]),
       username:new FormControl(null,[
        Validators.required,
        Validators.minLength(3),
      ]),
      balance:new FormControl(null,[
        Validators.required,
      ]),
      income:new FormControl(null,[
        Validators.required,
      ]),
      mobile:new FormControl(null,[
        Validators.required,
      ]),
      address:new FormControl(null,[
        Validators.required,
      ]),
      password:new FormControl(null,[Validators.required,Validators.minLength(4)]),
      
      date:new FormControl(null,[Validators.required])
    });
  
    this.id=this.route.snapshot.params['id'];
    console.log(this.id);
    this.AccountService.entities$.subscribe((accounts)=>
    {
      if (accounts.length) {
      const account=accounts.find((account)=>account.id === this.id);
      this.editForm.patchValue({
        accounttype:account.accounttype,
        firstname:account.firstname,
        lastname:account.lastname,
        email:account.email,
        gender:account.gender,
        date:account.date,
        username:account.username,
        password:account.password,
        balance:account.balance,
        address:account.address,
        deposit:account.deposit,
      });
      console.log(accounts);
      console.log(account);
    }
    });
  }
  
  onEdit(){
   const accountData={
     ...this.editForm.value,
     id:this.id,
   };
   this.AccountService.update(accountData);
   this.editForm.reset();
   this.router.navigate(['/accounts']);
  }
  
}


